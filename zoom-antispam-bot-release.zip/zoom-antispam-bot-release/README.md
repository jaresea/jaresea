# Zoom Anti-Spam Bot — GitHub Release

This is a GitHub‑ready release package for your Zoom Anti‑Spam Bot.

## Installation

Upload the repository to GitHub, then edit `install.sh` and replace:

```
RAW_BOT_URL
```

with your actual GitHub raw link:

```
https://raw.githubusercontent.com/<yourname>/<repo>/main/bot.py
```

Run:

```bash
chmod +x install.sh
./install.sh
```

Start the bot:

```bash
./run.sh
```

Use ngrok:

```bash
ngrok http 5000
```

Paste that URL into your Zoom Webhook configuration.

## License

MIT
