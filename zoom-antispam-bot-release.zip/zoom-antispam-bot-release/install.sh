#!/bin/bash
echo "Zoom Anti-Spam Bot Installer"
echo "Make sure to replace RAW_BOT_URL in this file after uploading to GitHub."

BOT_URL="RAW_BOT_URL"

mkdir -p zoom-antispam-bot
cd zoom-antispam-bot || exit

python3 -m venv venv
source venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt

curl -L "$BOT_URL" -o bot.py

cp .env.example .env

echo "Installation complete."
