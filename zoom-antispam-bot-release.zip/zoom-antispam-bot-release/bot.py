import os
import requests
from flask import Flask, request
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

ACCOUNT_ID = os.getenv("ZOOM_ACCOUNT_ID")
CLIENT_ID = os.getenv("ZOOM_CLIENT_ID")
CLIENT_SECRET = os.getenv("ZOOM_CLIENT_SECRET")
HOST_USER_ID = os.getenv("HOST_USER_ID")

def get_access_token():
    url = "https://zoom.us/oauth/token"
    params = {"grant_type": "account_credentials","account_id": ACCOUNT_ID}
    response = requests.post(url, params=params, auth=(CLIENT_ID, CLIENT_SECRET))
    response.raise_for_status()
    return response.json()["access_token"]

def alert_host(sender, message):
    token = get_access_token()
    data = {"message": f"⚠️ Spam from {sender}: {message}", "to_contact": HOST_USER_ID}
    r = requests.post("https://api.zoom.us/v2/chat/users/me/messages",
        headers={"Authorization": f"Bearer {token}"}, json=data)
    return r.json()

def is_spam(text):
    spam_patterns = ["free money","click here","earn $$$","promo","buy now","bit.ly","http://","https://"]
    return any(p.lower() in text.lower() for p in spam_patterns)

@app.route("/zoomwebhook", methods=["POST"])
def zoom_webhook():
    event = request.json
    try:
        msg = event["payload"]["object"]["chat_message"]["content"]
        user = event["payload"]["object"]["participant"]["username"]
    except:
        return "ignored"
    print(f">>> MESSAGE FROM {user}: {msg}")
    if is_spam(msg):
        print("⚠️ SPAM DETECTED")
        alert_host(user, msg)
        with open("spam_log.txt", "a") as f:
            f.write(f"{user}: {msg}
")
    return "OK"

if __name__ == "__main__":
    app.run(port=5000)
