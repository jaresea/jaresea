import requests
from typing import Optional, Dict, Any

BASE = "https://api.zoom.us/v2"

class ZoomClient:
    def __init__(self, bot_token: str):
        if not bot_token:
            raise ValueError("ZOOM_BOT_TOKEN is required")
        self.headers = {
            "Authorization": f"Bearer {bot_token}",
            "Content-Type": "application/json"
        }

    def send_channel_message(self, channel_id: str, message: str) -> Optional[Dict[str, Any]]:
        url = f"{BASE}/chat/users/me/messages"
        payload = {"message": message, "to_channel": channel_id}
        r = requests.post(url, json=payload, headers=self.headers, timeout=15)
        if r.status_code >= 400:
            return None
        return r.json()

    def send_dm(self, to_jid_or_email: str, message: str) -> Optional[Dict[str, Any]]:
        url = f"{BASE}/chat/users/me/messages"
        payload = {"message": message, "to_jid": to_jid_or_email}
        r = requests.post(url, json=payload, headers=self.headers, timeout=15)
        if r.status_code >= 400:
            return None
        return r.json()

    def delete_message(self, message_id: str) -> bool:
        url = f"{BASE}/chat/users/me/messages/{message_id}"
        r = requests.delete(url, headers=self.headers, timeout=15)
        return r.status_code in (200, 204)

    def list_channel_members(self, channel_id: str):
        url = f"{BASE}/chat/channels/{channel_id}/members"
        r = requests.get(url, headers=self.headers, timeout=15)
        if r.status_code >= 400:
            return []
        return r.json().get("members", [])

    def remove_member(self, channel_id: str, member_id: str) -> bool:
        url = f"{BASE}/chat/channels/{channel_id}/members/{member_id}"
        r = requests.delete(url, headers=self.headers, timeout=15)
        return r.status_code in (200, 204)
