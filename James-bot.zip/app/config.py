from pydantic import BaseModel
from typing import List, Optional
import os

def _csv_env(name: str) -> list[str]:
    raw = os.getenv(name, "").strip()
    return [x.strip().lower() for x in raw.split(",") if x.strip()]

class Settings(BaseModel):
    zoom_bot_token: str = os.getenv("ZOOM_BOT_TOKEN", "")
    admin_alert_channel_id: str = os.getenv("ADMIN_ALERT_CHANNEL_ID", "")
    admin_alert_user_jid: str = os.getenv("ADMIN_ALERT_USER_JID", "")
    whitelist_users: List[str] = _csv_env("WHITELIST_USERS")
    whitelist_domains: List[str] = _csv_env("WHITELIST_DOMAINS")
    rate_limit_max_msgs: int = int(os.getenv("RATE_LIMIT_MAX_MSGS", "6"))
    rate_limit_window_seconds: int = int(os.getenv("RATE_LIMIT_WINDOW_SECONDS", "30"))
    enable_auto_remove: bool = os.getenv("ENABLE_AUTO_REMOVE", "false").lower() == "true"
    port: int = int(os.getenv("PORT", "8080"))
    webhook_secret: Optional[str] = os.getenv("WEBHOOK_SECRET") or None
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

settings = Settings()
