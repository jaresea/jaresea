from typing import Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
import logging

log = logging.getLogger(__name__)

SPAM = 1
HAM = 0

def build_pipeline() -> Pipeline:
    clf = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), min_df=1, max_df=0.9)),
        ("clf", SGDClassifier(loss="log_loss", max_iter=1000, tol=1e-3))
    ])
    return clf

def tiny_training_data():
    spam = [
        "Get free money now http://spam.com",
        "Click here to win now!!!",
        "Crypto giveaway airdrop link https://scam.org",
        "Loan approval guaranteed apply here",
        "Visit my profile for xxx content",
        "WhatsApp me now +123 spam deal",
    ]
    ham = [
        "Daily standup at 10:00",
        "Here is the project link and notes",
        "Please review the PR by EOD",
        "Welcome to the channel!",
        "Can someone share the build logs?",
        "Reminder: sprint planning tomorrow"
    ]
    X = spam + ham
    y = [SPAM]*len(spam) + [HAM]*len(ham)
    return X, y

def train_model() -> Tuple[Pipeline, float]:
    X, y = tiny_training_data()
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=42)
    pipe = build_pipeline()
    pipe.fit(Xtr, ytr)
    try:
        f1 = f1_score(yte, pipe.predict(Xte))
    except Exception:
        f1 = 0.0
    log.info("Tiny ML model trained. F1=%.3f (seed dataset)", f1)
    return pipe, f1
