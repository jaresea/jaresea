from typing import Dict, Tuple
import time

class RateLimiter:
    def __init__(self, window_seconds: int, max_msgs: int):
        self.window = window_seconds
        self.max_msgs = max_msgs
        self.state: Dict[str, Tuple[int, float]] = {}

    def hit(self, user_key: str) -> Tuple[int, bool]:
        now = time.time()
        cnt, start = self.state.get(user_key, (0, now))
        if now - start > self.window:
            cnt, start = 0, now
        cnt += 1
        self.state[user_key] = (cnt, start)
        return cnt, cnt > self.max_msgs
