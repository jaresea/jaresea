import re

URL_RE = re.compile(r'https?://\S+', re.IGNORECASE)
REPEAT_CHAR_RE = re.compile(r'(.)\1{6,}', re.IGNORECASE)

DEFAULT_KEYWORDS = [
    'free money','click here','win now','credit repair','loan approval',
    'xxx','nsfw','telegram','whatsapp','crypto giveaway','airdrop','visit my profile'
]

def heuristic_is_spam(text: str) -> bool:
    t = (text or '').lower()
    if not t.strip():
        return False
    if URL_RE.search(t):
        return True
    if REPEAT_CHAR_RE.search(t):
        return True
    for k in DEFAULT_KEYWORDS:
        if k in t:
            return True
    return False
