import logging, hmac, hashlib
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from typing import Dict, Any, Optional

from .config import settings
from .zoom_client import ZoomClient
from .rules import heuristic_is_spam
from .spam_model import train_model, SPAM
from .storage import RateLimiter

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
log = logging.getLogger("james-bot")

app = FastAPI(title="James-bot (Zoom Anti-Spam)")

zoom = ZoomClient(settings.zoom_bot_token)
model, f1 = train_model()
limiter = RateLimiter(settings.rate_limit_window_seconds, settings.rate_limit_max_msgs)

def in_whitelist(email_or_jid: str) -> bool:
    e = (email_or_jid or "").lower()
    if e in settings.whitelist_users:
        return True
    if "@" in e:
        domain = e.split("@")[-1]
        if domain in settings.whitelist_domains:
            return True
    return False

def verify_signature(req: Request, body: bytes):
    if not settings.webhook_secret:
        return
    sig = req.headers.get("X-Zoom-Signature", "")
    mac = hmac.new(settings.webhook_secret.encode(), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, mac):
        raise HTTPException(status_code=401, detail="Invalid signature")

def alert_admin(text: str):
    if settings.admin_alert_channel_id:
        zoom.send_channel_message(settings.admin_alert_channel_id, text)
    elif settings.admin_alert_user_jid:
        zoom.send_dm(settings.admin_alert_user_jid, text)

@app.post("/zoom/webhook")
async def zoom_webhook(request: Request):
    body = await request.body()
    try:
        verify_signature(request, body)
    except HTTPException:
        raise
    data = await request.json()
    event = data.get("event", "")
    payload = data.get("payload", {})

    if event != "chat_message.sent":
        return JSONResponse({"status": "ignored"})

    message: Dict[str, Any] = payload.get("message", {})
    content: str = message.get("content", "") or ""
    message_id: Optional[str] = message.get("id")
    sender: str = message.get("sender", "") or ""
    channel_id: str = payload.get("channel_id", "") or ""

    if not content or not channel_id:
        return JSONResponse({"status": "ignored"})

    if in_whitelist(sender):
        return JSONResponse({"status": "whitelisted"})

    count, too_fast = limiter.hit(f"{channel_id}:{sender}")
    if too_fast:
        if message_id:
            zoom.delete_message(message_id)
        alert_admin(f"Rate limit triggered by {sender} in {channel_id}. Count={count}.")
        if settings.enable_auto_remove:
            try:
                members = zoom.list_channel_members(channel_id)
                member_id = None
                for m in members:
                    if m.get("email","").lower() == sender.lower() or m.get("jid","").lower() == sender.lower():
                        member_id = m.get("id") or m.get("member_id")
                        break
                if member_id:
                    zoom.remove_member(channel_id, member_id)
                    alert_admin(f"Removed member {sender} ({member_id}) from channel {channel_id} for severe spam.")
            except Exception as e:
                log.exception("Auto remove failed: %s", e)
        return JSONResponse({"status": "rate_limited"})

    if heuristic_is_spam(content):
        if message_id:
            zoom.delete_message(message_id)
        zoom.send_dm(sender, "Your recent message was removed for suspected spam. If this was a mistake, reply 'appeal'.")
        alert_admin(f"Heuristic spam removed from {sender} in {channel_id}: {content[:200]}")
        return JSONResponse({"status": "spam_heuristic"})

    try:
        pred = model.predict([content])[0]
    except Exception:
        pred = 0

    if pred == SPAM:
        if message_id:
            zoom.delete_message(message_id)
        zoom.send_dm(sender, "Your message was removed by ML spam filter. If this was incorrect, reply 'appeal'.")
        alert_admin(f"ML spam removed from {sender} in {channel_id}: {content[:200]} (F1 seed={f1:.2f})")
        return JSONResponse({"status": "spam_ml"})

    return JSONResponse({"status": "ok"})

@app.get("/healthz")
async def healthz():
    return {"ok": True}
