# James-bot — Zoom Team Chat Anti-Spam Bot

Production-ready anti-spam bot for **Zoom Team Chat** using FastAPI, heuristics + ML, whitelists, rate limiting, and admin alerts. Dockerized and ready for GitHub Releases.

## Features
- Heuristics: URL, keyword, and repeat-character detection
- ML: TF‑IDF + SGDClassifier (seed dataset; extendable)
- Whitelists: users and domains
- Rate limiting: per-user/per-channel window; optional auto-remove
- Admin alerts: DM or channel
- FastAPI service with `/healthz`
- Dockerfile + Compose

## Zoom App Requirements
Create a **Chatbot App** in Zoom Marketplace with scopes:
- `chat_message:read`, `chat_message:write`
- `chat_channel:read`, `chat_channel:write`
Enable event subscription: `chat_message.sent` → your webhook endpoint `/zoom/webhook`.

## Configuration
Copy `.env.example` → `.env` and set required values.
- `ZOOM_BOT_TOKEN` (bot access token)
- `ADMIN_ALERT_CHANNEL_ID` or `ADMIN_ALERT_USER_JID`
Optional: `ENABLE_AUTO_REMOVE=true`, `WHITELIST_USERS`, `WHITELIST_DOMAINS`, `WEBHOOK_SECRET`.

## Run (Docker)
```bash
docker build -t james-bot -f docker/Dockerfile .
docker run --rm -p 8080:8080 --env-file .env james-bot
# or
docker compose up --build
```

## Local Dev
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

## Webhook
Set your Zoom app webhook URL to:
```
https://YOUR_DOMAIN/zoom/webhook
```

## Endpoints
- `POST /zoom/webhook`
- `GET /healthz`

## GitHub: push & release
```bash
git init
git add .
git commit -m "Initial commit: James-bot anti-spam for Zoom Chat"
git branch -M main
git remote add origin https://github.com/<your-account>/James-bot.git
git push -u origin main
```
Then create a **GitHub Release** and upload `James-bot.zip` or let Actions build a Docker image (optional).

## License
MIT
