#!/usr/bin/env bash
set -euo pipefail
IMAGE_NAME=james-bot:latest
docker build -t "$IMAGE_NAME" -f docker/Dockerfile .
echo "Built $IMAGE_NAME"
